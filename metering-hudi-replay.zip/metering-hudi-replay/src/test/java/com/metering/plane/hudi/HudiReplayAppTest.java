package com.metering.plane.hudi;

import com.metering.plane.hudi.service.HudiReplayService;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SaveMode;
import org.apache.spark.sql.SparkSession;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Path;
import java.time.Instant;

import static org.assertj.core.api.Assertions.assertThat;

class HudiReplayAppTest {

    private static SparkSession spark;

    @BeforeAll
    static void initSpark() {
        spark = SparkSession.builder()
                .appName("HudiTest")
                .master("local[2]")
                .config("spark.ui.enabled", "false")
                .config("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
                .config("spark.sql.hive.convertMetastoreParquet", "false")
                .getOrCreate();
    }

    @AfterAll
    static void closeSpark() {
        if (spark != null) spark.stop();
    }

    @Test
    @DisplayName("Verify Hudi correctly idempotently upserts replayed hourly windows")
    void testReplayUpsert(@TempDir Path tempDir) {
        String evidencePath = tempDir.resolve("evidence").toString();
        String hudiPath = tempDir.resolve("hudi_out").toString();

        spark.sql(
            "SELECT 'evt-1' AS event_id, 'tenant-1' AS tenant_id, 'api_call' AS meter_id, " +
            "TIMESTAMP '2026-10-05 10:10:00' AS event_timestamp, 'h1' AS payload_hash, '{}' AS raw_payload"
        ).write().mode(SaveMode.Overwrite).parquet(evidencePath);

        HudiReplayService service = new HudiReplayService(spark, evidencePath, hudiPath, false);

        service.executeReplay("tenant-1", Instant.parse("2026-10-05T00:00:00Z"), Instant.parse("2026-10-05T23:59:59Z"));

        Dataset<Row> firstRead = spark.read().format("org.apache.hudi").load(hudiPath);
        assertThat(firstRead.count()).isEqualTo(1L);
        assertThat(firstRead.first().<Double>getAs("raw_quantity")).isEqualTo(1.0);

        spark.sql(
            "SELECT 'evt-1' AS event_id, 'tenant-1' AS tenant_id, 'api_call' AS meter_id, " +
            "TIMESTAMP '2026-10-05 10:10:00' AS event_timestamp, 'h1' AS payload_hash, '{}' AS raw_payload " +
            "UNION ALL " +
            "SELECT 'evt-2', 'tenant-1', 'api_call', TIMESTAMP '2026-10-05 10:40:00', 'h2', '{}'"
        ).write().mode(SaveMode.Overwrite).parquet(evidencePath);

        service.executeReplay("tenant-1", Instant.parse("2026-10-05T00:00:00Z"), Instant.parse("2026-10-05T23:59:59Z"));

        Dataset<Row> secondRead = spark.read().format("org.apache.hudi").load(hudiPath);
        assertThat(secondRead.count()).isEqualTo(1L);
        assertThat(secondRead.first().<Double>getAs("raw_quantity")).isEqualTo(2.0);
    }
}
